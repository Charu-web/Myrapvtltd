# Calorye Hive Business — Meals Management Dashboard

A pixel-matched recreation of the Meals Management admin dashboard, built as a production-style React app.

![Tech](https://img.shields.io/badge/React-18-61DAFB) ![Tech](https://img.shields.io/badge/TypeScript-5-3178C6) ![Tech](https://img.shields.io/badge/Tailwind-3-38BDF8) ![Tech](https://img.shields.io/badge/Vite-5-646CFF)

## What's included

The **Dashboard / Meals Management** page is built to match the reference design pixel-for-pixel:

- Gradient red/pink sidebar with all 14 nav items, active state, "Withdraw Funds" button, Help/Logout footer — collapses into an animated mobile drawer below the `lg` breakpoint
- Header with search, dark-mode toggle, support icon, notifications dropdown, settings, and profile dropdown
- Four gradient statistic cards (Total Subscribers, Active Meal Plans, Recurring Revenue, Fulfillment Rate) with hover lift animation
- Active Meal Plans table: search (debounced), column sorting, pagination, row hover, status badges (Active / Paused / Draft), and a row-level actions menu (Edit / Delete)
- Right sidebar: 7-day Menu Rotation calendar with per-day prep notes, and a Subscription Updates card (upcoming rotations, recent cancellations, "View Churn Report")
- Footer matching the exact reference copy (Services / Company / Legal columns, social icons, copyright bar)
- "+ Create New Meal Plan" modal — full create/edit form validated with **React Hook Form + Zod**
- Skeleton loading states, error states with retry, and success/error toasts wired to a **mock REST API + TanStack Query** layer (`GET/POST/PUT/DELETE /api/meal-plans`, `/api/dashboard`, `/api/menu-rotation`, `/api/subscriptions`)
- Dark mode (persisted to localStorage), Framer Motion page transitions, card fade-ins, button ripple effect

**Other sidebar sections** (Orders, Menu, Analytics, Loyalty, Catering, Meals, Marketing, Offers, Staff, Reviews, Transactions, Inventory, Profile, Help) are wired up as routes using a shared, on-brand placeholder page, since the reference image only specifies the Meals Management screen in detail. They're ready to be built out with the same components (`Card`, `StatCard`, `MealPlansTable` pattern, etc.) once you have real data/designs for them.

## Tech stack

React 18 · Vite · TypeScript · Tailwind CSS · React Router · React Icons · Framer Motion · Axios · TanStack Query · Recharts (installed, ready for Analytics charts) · React Hook Form · Zod

## Project structure

```
src/
  components/
    layout/        Sidebar, Header, Footer, DashboardLayout
    ui/             Button, Card, Badge, Avatar, SearchInput, Dropdown, Modal, Skeleton, ErrorState
    StatCard.tsx, MealPlansTable.tsx, MenuRotationCard.tsx,
    SubscriptionUpdatesCard.tsx, CreateMealPlanModal.tsx
  pages/            Dashboard.tsx (Meals Management), PlaceholderPage.tsx
  hooks/            useMealPlans, useDashboardStats, useMenuRotation,
                    useSubscriptionUpdates, useDebounce (all React Query)
  services/         api.ts — mock REST layer (swap for real axios calls)
  context/          ThemeContext (dark mode), ToastContext
  data/             Dummy JSON: 12 meal plans, dashboard stats, 7-day rotation, 10 subscription updates
  types/            Shared TypeScript interfaces
  utils/            cn() class-merging helper
```

## Installation

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev
# → http://localhost:5173

# 3. Build for production
npm run build

# 4. Preview the production build
npm run preview

# 5. Lint
npm run lint
```

## Connecting a real backend

All data currently comes from `src/services/api.ts`, which simulates network latency and mutates an in-memory store so create/edit/delete feel real for the duration of a session. To connect a real API:

1. Set `VITE_API_BASE_URL` in a `.env` file (defaults to `/api`).
2. Replace the body of each function in `api.ts` with a real call through the pre-configured `apiClient` (an axios instance), e.g.:
   ```ts
   export async function fetchMealPlans(): Promise<MealPlan[]> {
     const { data } = await apiClient.get('/meal-plans')
     return data
   }
   ```
3. The React Query hooks in `src/hooks/` don't need to change — they already invalidate the right query keys on mutation.

## Design tokens

| Token | Value |
|---|---|
| Primary Red | `#E11D48` |
| Secondary Red | `#EF4444` |
| Light Pink | `#FECDD3` |
| Surface / Gray | `#F8FAFC` |
| Dark Text | `#111827` |
| Border | `#E5E7EB` |
| Font | Inter |
