import { Routes, Route } from 'react-router-dom'
import {
  FiShoppingBag,
  FiMenu,
  FiBarChart2,
  FiAward,
  FiTruck,
  FiClipboard,
  FiTrendingUp,
  FiTag,
  FiUsers,
  FiStar,
  FiCreditCard,
  FiBox,
  FiUser,
  FiHelpCircle,
} from 'react-icons/fi'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import Dashboard from '@/pages/Dashboard'
import { PlaceholderPage } from '@/pages/PlaceholderPage'

export default function App() {
  return (
    <Routes>
      <Route element={<DashboardLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route
          path="/orders"
          element={
            <PlaceholderPage title="Orders" description="Track and fulfill incoming meal plan orders." icon={FiShoppingBag} />
          }
        />
        <Route
          path="/menu"
          element={<PlaceholderPage title="Menu" description="Build and organize your recipe and menu library." icon={FiMenu} />}
        />
        <Route
          path="/analytics"
          element={
            <PlaceholderPage title="Analytics" description="Deep-dive into revenue, retention and growth trends." icon={FiBarChart2} />
          }
        />
        <Route
          path="/loyalty"
          element={<PlaceholderPage title="Loyalty" description="Manage rewards and repeat-customer perks." icon={FiAward} />}
        />
        <Route
          path="/catering"
          element={<PlaceholderPage title="Catering" description="Coordinate catering orders and event logistics." icon={FiTruck} />}
        />
        <Route
          path="/meals"
          element={
            <PlaceholderPage title="Meals" description="Browse the full catalog of meals across every plan." icon={FiClipboard} />
          }
        />
        <Route
          path="/marketing"
          element={
            <PlaceholderPage title="Marketing" description="Plan campaigns and promotions for your subscribers." icon={FiTrendingUp} />
          }
        />
        <Route
          path="/offers"
          element={<PlaceholderPage title="Offers" description="Create and schedule discounts and bundle offers." icon={FiTag} />}
        />
        <Route
          path="/staff"
          element={<PlaceholderPage title="Staff" description="Manage roles, shifts and staff permissions." icon={FiUsers} />}
        />
        <Route
          path="/reviews"
          element={<PlaceholderPage title="Reviews" description="Read and respond to customer feedback." icon={FiStar} />}
        />
        <Route
          path="/transactions"
          element={
            <PlaceholderPage title="Transactions" description="View payment history and manage payouts." icon={FiCreditCard} />
          }
        />
        <Route
          path="/inventory"
          element={<PlaceholderPage title="Inventory" description="Track ingredient stock and supplier orders." icon={FiBox} />}
        />
        <Route
          path="/profile"
          element={<PlaceholderPage title="Profile" description="Update your business profile and preferences." icon={FiUser} />}
        />
        <Route
          path="/help"
          element={<PlaceholderPage title="Help" description="Find answers or contact the support team." icon={FiHelpCircle} />}
        />
      </Route>
    </Routes>
  )
}
