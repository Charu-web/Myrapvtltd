export type MealPlanStatus = 'Active' | 'Paused' | 'Draft'

export interface MealPlan {
  id: string
  name: string
  subtitle: string
  imageColor: string
  emoji: string
  subscribers: number
  price: string
  status: MealPlanStatus
  createdAt: string
}

export interface DashboardStats {
  totalSubscribers: number
  subscribersDelta: string
  activeMealPlans: number
  activeMealPlansDelta: string
  monthlyRevenue: number
  monthlyRevenueDelta: string
  fulfillmentRate: number
}

export interface CalendarDay {
  id: string
  label: string
  date: number
  isSelected: boolean
  isToday: boolean
}

export interface MealPrep {
  dayId: string
  title: string
  description: string
}

export interface MenuRotation {
  currentMenu: string
  days: CalendarDay[]
  prep: MealPrep[]
}

export type UpdateKind = 'rotation' | 'cancellation' | 'new-subscriber'

export interface SubscriptionUpdate {
  id: string
  kind: UpdateKind
  title: string
  description: string
  initials?: string
  tag?: string
  date?: string
}

export interface SubscriptionUpdates {
  upcomingRotations: SubscriptionUpdate[]
  recentCancellations: SubscriptionUpdate[]
  recentNewSubscribers: SubscriptionUpdate[]
}

export interface NavItem {
  label: string
  icon: string
  path: string
}
