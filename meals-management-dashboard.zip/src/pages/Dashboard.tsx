import { useState } from 'react'
import { FiPlus, FiUsers, FiClipboard, FiDollarSign, FiCheckCircle } from 'react-icons/fi'
import { Button } from '@/components/ui/Button'
import { StatCard } from '@/components/StatCard'
import { MealPlansTable } from '@/components/MealPlansTable'
import { MenuRotationCard } from '@/components/MenuRotationCard'
import { SubscriptionUpdatesCard } from '@/components/SubscriptionUpdatesCard'
import { CreateMealPlanModal } from '@/components/CreateMealPlanModal'
import { useMealPlans } from '@/hooks/useMealPlans'
import { useDashboardStats } from '@/hooks/useDashboardStats'
import { useMenuRotation } from '@/hooks/useMenuRotation'
import { useSubscriptionUpdates } from '@/hooks/useSubscriptionUpdates'
import { MealPlan } from '@/types'

export default function Dashboard() {
  const [modalOpen, setModalOpen] = useState(false)
  const [editingPlan, setEditingPlan] = useState<MealPlan | null>(null)

  const mealPlansQuery = useMealPlans()
  const statsQuery = useDashboardStats()
  const rotationQuery = useMenuRotation()
  const updatesQuery = useSubscriptionUpdates()

  const stats = statsQuery.data

  const openCreateModal = () => {
    setEditingPlan(null)
    setModalOpen(true)
  }

  const openEditModal = (plan: MealPlan) => {
    setEditingPlan(plan)
    setModalOpen(true)
  }

  return (
    <div className="pb-4">
      {/* Page header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-[28px] font-extrabold text-ink dark:text-white tracking-tight">
            Meals Management
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Manage your recurring meal plans and subscription rotations.
          </p>
        </div>
        <Button variant="dark" icon={<FiPlus />} onClick={openCreateModal} className="self-start sm:self-auto">
          Create New Meal plan
        </Button>
      </div>

      {/* Stat cards */}
      <div className="mt-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          index={0}
          tone="lightAlt"
          label="Total Subscribers"
          value={stats ? stats.totalSubscribers.toString() : '—'}
          delta={stats?.subscribersDelta}
          icon={<FiUsers />}
        />
        <StatCard
          index={1}
          tone="mid"
          label="Active Meal Plans"
          value={stats ? stats.activeMealPlans.toString() : '—'}
          delta={stats?.activeMealPlansDelta}
          icon={<FiClipboard />}
        />
        <StatCard
          index={2}
          tone="dark"
          label="Recurring Revenue (Monthly)"
          value={stats ? `$${stats.monthlyRevenue.toLocaleString()}` : '—'}
          delta={stats?.monthlyRevenueDelta}
          icon={<FiDollarSign />}
        />
        <StatCard
          index={3}
          tone="light"
          label="Fulfillment Rate"
          value={stats ? `${stats.fulfillmentRate}%` : '—'}
          icon={<FiCheckCircle />}
        />
      </div>

      {/* Main grid: table + right sidebar */}
      <div className="mt-6 grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6 items-start">
        <MealPlansTable
          mealPlans={mealPlansQuery.data}
          isLoading={mealPlansQuery.isLoading}
          isError={mealPlansQuery.isError}
          onRetry={() => mealPlansQuery.refetch()}
          onEdit={openEditModal}
        />

        <div className="space-y-6">
          <MenuRotationCard
            data={rotationQuery.data}
            isLoading={rotationQuery.isLoading}
            isError={rotationQuery.isError}
            onRetry={() => rotationQuery.refetch()}
          />
          <SubscriptionUpdatesCard
            data={updatesQuery.data}
            isLoading={updatesQuery.isLoading}
            isError={updatesQuery.isError}
            onRetry={() => updatesQuery.refetch()}
          />
        </div>
      </div>

      <CreateMealPlanModal isOpen={modalOpen} onClose={() => setModalOpen(false)} editingPlan={editingPlan} />
    </div>
  )
}
