import { IconType } from 'react-icons'
import { Card } from '@/components/ui/Card'

export function PlaceholderPage({
  title,
  description,
  icon: Icon,
}: {
  title: string
  description: string
  icon: IconType
}) {
  return (
    <div className="pb-4">
      <div>
        <h1 className="text-2xl sm:text-[28px] font-extrabold text-ink dark:text-white tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{description}</p>
      </div>

      <Card className="mt-6 flex flex-col items-center justify-center text-center py-20 px-6">
        <div className="h-14 w-14 rounded-2xl bg-primary-50 dark:bg-primary-500/10 text-primary-600 flex items-center justify-center text-2xl mb-4">
          <Icon />
        </div>
        <h2 className="text-lg font-bold text-ink dark:text-white">{title} is coming together</h2>
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400 max-w-sm">
          This section follows the same design system as Meals Management — sidebar, header, cards and tables are
          ready to wire up to your real {title.toLowerCase()} data whenever the API is available.
        </p>
      </Card>
    </div>
  )
}
