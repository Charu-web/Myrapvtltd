import { useQuery } from '@tanstack/react-query'
import { fetchSubscriptionUpdates } from '@/services/api'

export function useSubscriptionUpdates() {
  return useQuery({
    queryKey: ['subscription-updates'],
    queryFn: fetchSubscriptionUpdates,
  })
}
