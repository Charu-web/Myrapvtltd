import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  fetchMealPlans,
  createMealPlan,
  updateMealPlan,
  deleteMealPlan,
} from '@/services/api'
import { MealPlan } from '@/types'

export const MEAL_PLANS_KEY = ['meal-plans']

export function useMealPlans() {
  return useQuery({
    queryKey: MEAL_PLANS_KEY,
    queryFn: fetchMealPlans,
  })
}

export function useCreateMealPlan() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: Omit<MealPlan, 'id' | 'createdAt'>) => createMealPlan(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: MEAL_PLANS_KEY })
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] })
    },
  })
}

export function useUpdateMealPlan() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Partial<MealPlan> }) =>
      updateMealPlan(id, patch),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: MEAL_PLANS_KEY })
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] })
    },
  })
}

export function useDeleteMealPlan() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => deleteMealPlan(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: MEAL_PLANS_KEY })
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] })
    },
  })
}
