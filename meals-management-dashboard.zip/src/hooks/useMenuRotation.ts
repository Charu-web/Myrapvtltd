import { useQuery } from '@tanstack/react-query'
import { fetchMenuRotation } from '@/services/api'

export function useMenuRotation() {
  return useQuery({
    queryKey: ['menu-rotation'],
    queryFn: fetchMenuRotation,
  })
}
