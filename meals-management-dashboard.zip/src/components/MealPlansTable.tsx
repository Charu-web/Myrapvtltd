import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { FiMoreVertical, FiChevronLeft, FiChevronRight, FiArrowUp, FiArrowDown, FiEdit2, FiTrash2 } from 'react-icons/fi'
import { MealPlan } from '@/types'
import { StatusBadge } from '@/components/ui/Badge'
import { SearchInput } from '@/components/ui/SearchInput'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/ErrorState'
import { Dropdown } from '@/components/ui/Dropdown'
import { useDebounce } from '@/hooks/useDebounce'
import { useDeleteMealPlan } from '@/hooks/useMealPlans'
import { useToast } from '@/context/ToastContext'

type SortKey = 'name' | 'subscribers' | 'price' | 'status'
const PAGE_SIZE = 6

export function MealPlansTable({
  mealPlans,
  isLoading,
  isError,
  onRetry,
  onEdit,
}: {
  mealPlans: MealPlan[] | undefined
  isLoading: boolean
  isError: boolean
  onRetry: () => void
  onEdit: (plan: MealPlan) => void
}) {
  const [search, setSearch] = useState('')
  const debouncedSearch = useDebounce(search, 300)
  const [sortKey, setSortKey] = useState<SortKey>('subscribers')
  const [sortAsc, setSortAsc] = useState(false)
  const [page, setPage] = useState(1)
  const deleteMealPlan = useDeleteMealPlan()
  const { showToast } = useToast()

  const filtered = useMemo(() => {
    const list = mealPlans ?? []
    const q = debouncedSearch.trim().toLowerCase()
    const searched = q ? list.filter((p) => p.name.toLowerCase().includes(q)) : list
    const sorted = [...searched].sort((a, b) => {
      let cmp = 0
      if (sortKey === 'name') cmp = a.name.localeCompare(b.name)
      else if (sortKey === 'subscribers') cmp = a.subscribers - b.subscribers
      else if (sortKey === 'price') cmp = parseFloat(a.price.replace(/[^0-9.]/g, '')) - parseFloat(b.price.replace(/[^0-9.]/g, ''))
      else if (sortKey === 'status') cmp = a.status.localeCompare(b.status)
      return sortAsc ? cmp : -cmp
    })
    return sorted
  }, [mealPlans, debouncedSearch, sortKey, sortAsc])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc((a) => !a)
    else {
      setSortKey(key)
      setSortAsc(true)
    }
    setPage(1)
  }

  const handleDelete = async (plan: MealPlan) => {
    try {
      await deleteMealPlan.mutateAsync(plan.id)
      showToast(`${plan.name} was deleted`, 'success')
    } catch {
      showToast('Could not delete meal plan', 'error')
    }
  }

  const SortIcon = ({ active }: { active: boolean }) =>
    active ? (sortAsc ? <FiArrowUp className="inline ml-1" /> : <FiArrowDown className="inline ml-1" />) : null

  return (
    <div>
      <div className="flex items-center justify-between gap-3 rounded-t-2xl bg-gradient-to-r from-sky-400 to-sky-500 px-5 py-3.5">
        <h3 className="text-white font-bold text-[15px]">Active Meal Plans</h3>
        <button className="text-white/90 text-xs font-semibold hover:text-white">View All</button>
      </div>

      <div className="border border-t-0 border-borderc/60 dark:border-white/10 rounded-b-2xl bg-white dark:bg-white/[0.03] overflow-hidden">
        <div className="p-4 border-b border-borderc/60 dark:border-white/10">
          <SearchInput value={search} onChange={(v) => { setSearch(v); setPage(1) }} placeholder="Search meal plans..." />
        </div>

        {isError ? (
          <ErrorState onRetry={onRetry} message="We couldn't load your meal plans." />
        ) : isLoading ? (
          <div className="p-4 space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton className="h-10 w-10 rounded-lg" />
                <Skeleton className="h-4 flex-1 max-w-[180px]" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-6 w-16 rounded-full" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-14 text-center text-sm text-gray-400">
            No meal plans match “{debouncedSearch}”.
          </div>
        ) : (
          <>
            <div className="overflow-x-auto scrollbar-thin">
              <table className="w-full min-w-[640px] text-left">
                <thead>
                  <tr className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
                    <th className="px-5 py-3 cursor-pointer select-none" onClick={() => toggleSort('name')}>
                      Plan Name <SortIcon active={sortKey === 'name'} />
                    </th>
                    <th className="px-5 py-3 cursor-pointer select-none" onClick={() => toggleSort('subscribers')}>
                      Subscribers <SortIcon active={sortKey === 'subscribers'} />
                    </th>
                    <th className="px-5 py-3 cursor-pointer select-none" onClick={() => toggleSort('price')}>
                      Price <SortIcon active={sortKey === 'price'} />
                    </th>
                    <th className="px-5 py-3 cursor-pointer select-none" onClick={() => toggleSort('status')}>
                      Status <SortIcon active={sortKey === 'status'} />
                    </th>
                    <th className="px-5 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pageItems.map((plan, i) => (
                    <motion.tr
                      key={plan.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: i * 0.03 }}
                      className="border-t border-borderc/50 dark:border-white/5 hover:bg-primary-50/40 dark:hover:bg-white/[0.04] transition-colors"
                    >
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <div
                            className="h-10 w-10 rounded-lg flex items-center justify-center text-lg shrink-0"
                            style={{ backgroundColor: plan.imageColor }}
                          >
                            {plan.emoji}
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-ink dark:text-gray-100 truncate">{plan.name}</p>
                            <p className="text-xs text-gray-400 truncate">{plan.subtitle}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-gray-300">{plan.subscribers}</td>
                      <td className="px-5 py-3.5 text-sm font-medium text-ink dark:text-gray-100">{plan.price}</td>
                      <td className="px-5 py-3.5">
                        <StatusBadge status={plan.status} />
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <Dropdown
                          trigger={
                            <span className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-white/5 text-gray-500 inline-flex">
                              <FiMoreVertical />
                            </span>
                          }
                          panelClassName="p-1 min-w-[150px]"
                        >
                          <button
                            onClick={() => onEdit(plan)}
                            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-ink dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-white/5 rounded-lg"
                          >
                            <FiEdit2 className="text-[13px]" /> Edit
                          </button>
                          <button
                            onClick={() => handleDelete(plan)}
                            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-500/10 rounded-lg"
                          >
                            <FiTrash2 className="text-[13px]" /> Delete
                          </button>
                        </Dropdown>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between px-5 py-3.5 border-t border-borderc/50 dark:border-white/5">
              <p className="text-xs text-gray-400">
                Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} of {filtered.length}
              </p>
              <div className="flex items-center gap-1.5">
                <button
                  disabled={page === 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="h-7 w-7 rounded-lg border border-borderc dark:border-white/10 flex items-center justify-center text-gray-500 disabled:opacity-30 hover:bg-gray-50 dark:hover:bg-white/5"
                >
                  <FiChevronLeft className="text-[13px]" />
                </button>
                <span className="text-xs font-medium text-gray-500 px-2">
                  {page} / {totalPages}
                </span>
                <button
                  disabled={page === totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  className="h-7 w-7 rounded-lg border border-borderc dark:border-white/10 flex items-center justify-center text-gray-500 disabled:opacity-30 hover:bg-gray-50 dark:hover:bg-white/5"
                >
                  <FiChevronRight className="text-[13px]" />
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
