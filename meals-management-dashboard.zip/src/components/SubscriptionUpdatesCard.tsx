import { FiRefreshCw } from 'react-icons/fi'
import { Card } from '@/components/ui/Card'
import { Avatar } from '@/components/ui/Avatar'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/ErrorState'
import { SubscriptionUpdates } from '@/types'

export function SubscriptionUpdatesCard({
  data,
  isLoading,
  isError,
  onRetry,
}: {
  data: SubscriptionUpdates | undefined
  isLoading: boolean
  isError: boolean
  onRetry: () => void
}) {
  if (isError) {
    return (
      <Card className="p-5">
        <ErrorState onRetry={onRetry} message="Couldn't load subscription updates." />
      </Card>
    )
  }

  if (isLoading || !data) {
    return (
      <Card className="p-5 space-y-3">
        <Skeleton className="h-4 w-36" />
        <Skeleton className="h-14 w-full rounded-xl" />
        <Skeleton className="h-10 w-full rounded-xl" />
        <Skeleton className="h-10 w-full rounded-xl" />
      </Card>
    )
  }

  return (
    <Card className="p-5 bg-gray-50 dark:bg-white/[0.03]">
      <h3 className="text-[15px] font-bold text-ink dark:text-white">Subscription Updates</h3>

      <div className="mt-4">
        <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Upcoming Rotations</p>
        <div className="mt-2 space-y-2">
          {data.upcomingRotations.slice(0, 1).map((u) => (
            <div key={u.id} className="flex items-start gap-3 rounded-xl bg-white dark:bg-white/5 p-3 border border-borderc/50 dark:border-white/10">
              <div className="h-8 w-8 rounded-lg bg-primary-100 dark:bg-primary-500/10 text-primary-600 flex items-center justify-center shrink-0">
                <FiRefreshCw className="text-[13px]" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-ink dark:text-gray-100">{u.title}</p>
                <p className="text-[11px] text-gray-400 mt-0.5">{u.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Recent Cancellations</p>
        <span className="text-[10px] font-bold bg-primary-100 text-primary-700 dark:bg-primary-500/15 dark:text-primary-300 rounded-full px-2 py-0.5">
          {data.recentCancellations.length} this week
        </span>
      </div>
      <div className="mt-2 space-y-2">
        {data.recentCancellations.slice(0, 2).map((u) => (
          <div key={u.id} className="flex items-center gap-3 rounded-xl bg-white dark:bg-white/5 p-2.5 border border-borderc/50 dark:border-white/10">
            <Avatar initials={u.initials ?? '?'} size={30} />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-ink dark:text-gray-100 truncate">{u.title}</p>
              <p className="text-[11px] text-gray-400 truncate">{u.description}</p>
            </div>
            <span className="text-[10px] font-semibold text-gray-500 bg-gray-100 dark:bg-white/10 rounded-full px-2 py-1 shrink-0">
              {u.tag}
            </span>
          </div>
        ))}
      </div>

      <Button variant="dark" size="sm" className="mt-4 w-full">
        View Churn Report
      </Button>
    </Card>
  )
}
