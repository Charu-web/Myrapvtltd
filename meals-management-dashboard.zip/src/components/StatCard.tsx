import React from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/utils/cn'

interface StatCardProps {
  label: string
  value: string
  delta?: string
  icon: React.ReactNode
  tone: 'light' | 'mid' | 'dark' | 'lightAlt'
  index: number
}

const toneClasses: Record<StatCardProps['tone'], string> = {
  light: 'bg-gradient-to-br from-primary-200 via-primary-300 to-primary-400 text-primary-900',
  mid: 'bg-gradient-to-br from-primary-500 via-primary-600 to-primary-700 text-white',
  dark: 'bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white',
  lightAlt: 'bg-gradient-to-br from-rose-50 via-primary-100 to-primary-200 text-primary-900',
}

export function StatCard({ label, value, delta, icon, tone, index }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.06, ease: 'easeOut' }}
      whileHover={{ y: -4 }}
      className={cn(
        'relative overflow-hidden rounded-2xl p-5 shadow-card transition-shadow duration-300 hover:shadow-cardhover cursor-default',
        toneClasses[tone]
      )}
    >
      <div className="absolute -right-4 -top-4 h-20 w-20 rounded-full bg-white/10" />
      <div className="flex items-start justify-between">
        <p className="text-[13px] font-semibold opacity-80">{label}</p>
        <div className="h-9 w-9 rounded-xl bg-white/25 flex items-center justify-center text-[16px]">
          {icon}
        </div>
      </div>
      <p className="mt-3 text-3xl font-extrabold tracking-tight">{value}</p>
      {delta && <p className="mt-1 text-xs font-medium opacity-75">{delta}</p>}
    </motion.div>
  )
}
