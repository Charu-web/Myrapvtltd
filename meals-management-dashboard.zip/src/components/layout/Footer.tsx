import { FiFeather, FiSun, FiCloud } from 'react-icons/fi'

const columns = [
  {
    title: 'Services',
    links: ['Temporal Audits', 'Atmospheric UI', 'Precision Scheduling', 'Focus Flux'],
  },
  {
    title: 'Company',
    links: ['Our Philosophy', 'Global Offices', 'Research Lab', 'Careers'],
  },
  {
    title: 'Legal',
    links: ['Privacy Policy', 'Terms of Service', 'Cookie Settings', 'Ethics Charter'],
  },
]

export function Footer() {
  return (
    <footer className="mt-8 pt-8 pb-6">
      <div className="grid grid-cols-1 md:grid-cols-[1.4fr_1fr_1fr_1fr] gap-8">
        <div>
          <h3 className="text-sm font-extrabold tracking-wide text-ink dark:text-white uppercase">
            Calorye Hive Business
          </h3>
          <p className="mt-3 text-sm text-gray-500 dark:text-gray-400 max-w-xs leading-relaxed">
            Advancing atmospheric precision in temporal management. We create digital environments
            that respect the fluidity of human attention and the rigidity of time.
          </p>
          <div className="mt-4 flex items-center gap-2">
            {[FiFeather, FiSun, FiCloud].map((Icon, i) => (
              <button
                key={i}
                aria-label="Social link"
                className="h-8 w-8 rounded-full bg-ink dark:bg-white/10 text-white flex items-center justify-center hover:bg-primary-600 transition-colors"
              >
                <Icon className="text-[13px]" />
              </button>
            ))}
          </div>
        </div>

        {columns.map((col) => (
          <div key={col.title}>
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider">{col.title}</h4>
            <ul className="mt-3 space-y-2.5">
              {col.links.map((link) => (
                <li key={link}>
                  <a href="#" className="text-sm text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-8 pt-5 border-t border-borderc dark:border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2">
        <p className="text-xs text-gray-400">© 2026 Calorye Hive Business. All rights reserved.</p>
        <p className="text-xs text-gray-300 dark:text-gray-600 tracking-wide">
          PRECISION GUARANTEED &nbsp;•&nbsp; GLOBAL COVERAGE
        </p>
      </div>
    </footer>
  )
}
