import { FiHeadphones, FiBell, FiSettings, FiMenu, FiMoon, FiSun, FiCheck, FiLogOut, FiUser } from 'react-icons/fi'
import { SearchInput } from '@/components/ui/SearchInput'
import { Avatar } from '@/components/ui/Avatar'
import { Dropdown } from '@/components/ui/Dropdown'
import { useTheme } from '@/context/ThemeContext'
import { useState } from 'react'

const notifications = [
  { id: 1, text: 'New subscriber joined Healthy Office Lunch', time: '5m ago' },
  { id: 2, text: 'Vegan Power Bowls plan was paused', time: '1h ago' },
  { id: 3, text: 'Monthly revenue report is ready', time: '3h ago' },
]

export function Header({ onOpenMobileMenu }: { onOpenMobileMenu: () => void }) {
  const { theme, toggleTheme } = useTheme()
  const [search, setSearch] = useState('')

  return (
    <header className="flex items-center gap-3 pt-1 pb-2">
      <button
        onClick={onOpenMobileMenu}
        aria-label="Open menu"
        className="lg:hidden p-2 rounded-xl bg-white dark:bg-white/5 shadow-card text-ink dark:text-gray-200"
      >
        <FiMenu />
      </button>

      <SearchInput value={search} onChange={setSearch} placeholder="Search activities" className="hidden sm:flex" />

      <div className="ml-auto flex items-center gap-2 sm:gap-3">
        <button
          onClick={toggleTheme}
          aria-label="Toggle dark mode"
          className="h-10 w-10 rounded-full bg-white dark:bg-white/5 shadow-card flex items-center justify-center text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors"
        >
          {theme === 'dark' ? <FiSun /> : <FiMoon />}
        </button>

        <button
          aria-label="Support"
          className="hidden sm:flex h-10 w-10 rounded-full bg-white dark:bg-white/5 shadow-card items-center justify-center text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors"
        >
          <FiHeadphones />
        </button>

        <Dropdown
          trigger={
            <span className="relative h-10 w-10 rounded-full bg-white dark:bg-white/5 shadow-card flex items-center justify-center text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors">
              <FiBell />
              <span className="absolute top-2 right-2.5 h-1.5 w-1.5 rounded-full bg-primary-600" />
            </span>
          }
          panelClassName="p-1"
        >
          <div className="px-3 py-2 text-xs font-bold text-gray-400 uppercase tracking-wide">Notifications</div>
          {notifications.map((n) => (
            <div key={n.id} className="px-3 py-2.5 hover:bg-gray-50 dark:hover:bg-white/5 rounded-lg mx-1 cursor-pointer">
              <p className="text-sm text-ink dark:text-gray-100">{n.text}</p>
              <p className="text-xs text-gray-400 mt-0.5">{n.time}</p>
            </div>
          ))}
        </Dropdown>

        <button
          aria-label="Settings"
          className="hidden sm:flex h-10 w-10 rounded-full bg-white dark:bg-white/5 shadow-card items-center justify-center text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors"
        >
          <FiSettings />
        </button>

        <Dropdown
          trigger={
            <span>
              <Avatar initials="BH" size={40} />
            </span>
          }
          panelClassName="p-1"
        >
          <button className="w-full flex items-center gap-2 px-3 py-2.5 text-sm text-ink dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-white/5 rounded-lg mx-0">
            <FiUser /> View Profile
          </button>
          <button className="w-full flex items-center gap-2 px-3 py-2.5 text-sm text-ink dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-white/5 rounded-lg mx-0">
            <FiCheck /> Account Settings
          </button>
          <div className="h-px bg-borderc dark:bg-white/10 my-1 mx-2" />
          <button className="w-full flex items-center gap-2 px-3 py-2.5 text-sm text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-500/10 rounded-lg mx-0">
            <FiLogOut /> Logout
          </button>
        </Dropdown>
      </div>
    </header>
  )
}
