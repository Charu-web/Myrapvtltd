import { NavLink } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  FiGrid,
  FiShoppingBag,
  FiMenu,
  FiBarChart2,
  FiAward,
  FiTruck,
  FiClipboard,
  FiTrendingUp,
  FiTag,
  FiUsers,
  FiStar,
  FiCreditCard,
  FiBox,
  FiUser,
  FiHelpCircle,
  FiLogOut,
  FiX,
} from 'react-icons/fi'
import { cn } from '@/utils/cn'

const navItems = [
  { label: 'Dashboard', icon: FiGrid, path: '/' },
  { label: 'Orders', icon: FiShoppingBag, path: '/orders' },
  { label: 'Menu', icon: FiMenu, path: '/menu' },
  { label: 'Analytics', icon: FiBarChart2, path: '/analytics' },
  { label: 'Loyalty', icon: FiAward, path: '/loyalty' },
  { label: 'Catering', icon: FiTruck, path: '/catering' },
  { label: 'Meals', icon: FiClipboard, path: '/meals' },
  { label: 'Marketing', icon: FiTrendingUp, path: '/marketing' },
  { label: 'Offers', icon: FiTag, path: '/offers' },
  { label: 'Staff', icon: FiUsers, path: '/staff' },
  { label: 'Reviews', icon: FiStar, path: '/reviews' },
  { label: 'Transactions', icon: FiCreditCard, path: '/transactions' },
  { label: 'Inventory', icon: FiBox, path: '/inventory' },
  { label: 'Profile', icon: FiUser, path: '/profile' },
]

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <div className="flex h-full flex-col bg-gradient-to-b from-[#8f1024] via-[#c1123f] to-[#e11d48] rounded-2xl px-3 py-4 shadow-sidebar">
      {/* Logo */}
      <div className="flex items-center gap-2 rounded-xl bg-white/95 px-3 py-2.5 mb-4">
        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center text-white font-extrabold text-xs shrink-0">
          OH
        </div>
        <div className="leading-tight">
          <p className="text-[13px] font-extrabold text-ink">Business</p>
          <p className="text-[11px] font-medium text-gray-500 -mt-0.5">Account</p>
        </div>
      </div>

      {/* Active now pill */}
      <div className="rounded-lg bg-white/15 text-white text-[10px] font-bold tracking-wider text-center py-1.5 mb-3 uppercase">
        Active Now
      </div>

      {/* Nav items */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin -mx-1 px-1 space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            onClick={onNavigate}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-all duration-150',
                isActive
                  ? 'bg-white text-primary-700 shadow-card'
                  : 'text-white/90 hover:bg-white/10'
              )
            }
          >
            <item.icon className="text-[15px] shrink-0" />
            <span className="truncate">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Withdraw funds button */}
      <button className="mt-3 rounded-xl bg-ink text-white text-[13px] font-semibold py-2.5 flex items-center justify-center gap-2 hover:bg-black transition-colors">
        <FiCreditCard className="text-[14px]" />
        Withdraw Funds
      </button>

      <div className="h-px bg-white/15 my-3" />

      {/* Bottom items */}
      <div className="space-y-1">
        <NavLink
          to="/help"
          onClick={onNavigate}
          className="flex items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-semibold text-white/85 hover:bg-white/10 transition-colors"
        >
          <FiHelpCircle className="text-[15px]" />
          Help
        </NavLink>
        <button className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-semibold text-white/85 hover:bg-white/10 transition-colors">
          <FiLogOut className="text-[15px]" />
          Logout
        </button>
      </div>
    </div>
  )
}

export function Sidebar({
  mobileOpen,
  onCloseMobile,
}: {
  mobileOpen: boolean
  onCloseMobile: () => void
}) {
  return (
    <>
      {/* Desktop / tablet-collapsed sidebar */}
      <aside className="hidden lg:block w-[240px] shrink-0 p-3 sticky top-0 h-screen">
        <SidebarContent />
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-black/50 lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onCloseMobile}
            />
            <motion.div
              className="fixed left-0 top-0 z-50 h-full w-[260px] p-3 lg:hidden"
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 28, stiffness: 260 }}
            >
              <div className="relative h-full">
                <button
                  onClick={onCloseMobile}
                  aria-label="Close menu"
                  className="absolute -right-1 top-1 z-10 rounded-full bg-white/90 p-1.5 text-ink shadow-card"
                >
                  <FiX />
                </button>
                <SidebarContent onNavigate={onCloseMobile} />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
