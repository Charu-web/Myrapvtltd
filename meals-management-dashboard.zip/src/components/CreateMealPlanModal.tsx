import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Modal } from '@/components/ui/Modal'
import { Button } from '@/components/ui/Button'
import { MealPlan } from '@/types'
import { useCreateMealPlan, useUpdateMealPlan } from '@/hooks/useMealPlans'
import { useToast } from '@/context/ToastContext'

const schema = z.object({
  name: z.string().min(3, 'Plan name must be at least 3 characters'),
  subtitle: z.string().min(2, 'Add a short subtitle'),
  subscribers: z.coerce.number().int().min(0, 'Must be 0 or more'),
  price: z.string().min(1, 'Price is required'),
  status: z.enum(['Active', 'Paused', 'Draft']),
})

type FormValues = z.infer<typeof schema>

const emojiPalette = ['🥗', '🍲', '🥦', '🥑', '🍗', '🍱', '🥙', '🍽️']
const colorPalette = ['#FDE68A', '#FCA5A5', '#86EFAC', '#93C5FD', '#C4B5FD', '#5EEAD4', '#FBCFE8']

export function CreateMealPlanModal({
  isOpen,
  onClose,
  editingPlan,
}: {
  isOpen: boolean
  onClose: () => void
  editingPlan?: MealPlan | null
}) {
  const createMealPlan = useCreateMealPlan()
  const updateMealPlan = useUpdateMealPlan()
  const { showToast } = useToast()

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: '',
      subtitle: '',
      subscribers: 0,
      price: '',
      status: 'Draft',
    },
  })

  useEffect(() => {
    if (editingPlan) {
      reset({
        name: editingPlan.name,
        subtitle: editingPlan.subtitle,
        subscribers: editingPlan.subscribers,
        price: editingPlan.price,
        status: editingPlan.status,
      })
    } else {
      reset({ name: '', subtitle: '', subscribers: 0, price: '', status: 'Draft' })
    }
  }, [editingPlan, isOpen, reset])

  const onSubmit = async (values: FormValues) => {
    try {
      if (editingPlan) {
        await updateMealPlan.mutateAsync({ id: editingPlan.id, patch: values })
        showToast(`${values.name} was updated`, 'success')
      } else {
        const emoji = emojiPalette[Math.floor(Math.random() * emojiPalette.length)]
        const imageColor = colorPalette[Math.floor(Math.random() * colorPalette.length)]
        await createMealPlan.mutateAsync({ ...values, emoji, imageColor })
        showToast(`${values.name} was created`, 'success')
      }
      onClose()
    } catch {
      showToast('Something went wrong. Please try again.', 'error')
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={editingPlan ? 'Edit Meal Plan' : 'Create New Meal Plan'}>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="text-xs font-semibold text-gray-500">Plan Name</label>
          <input
            {...register('name')}
            className="mt-1 w-full rounded-xl border border-borderc dark:border-white/10 bg-transparent px-3.5 py-2.5 text-sm outline-none focus:border-primary-400"
            placeholder="e.g. Mediterranean Reset"
          />
          {errors.name && <p className="mt-1 text-xs text-primary-600">{errors.name.message}</p>}
        </div>

        <div>
          <label className="text-xs font-semibold text-gray-500">Subtitle</label>
          <input
            {...register('subtitle')}
            className="mt-1 w-full rounded-xl border border-borderc dark:border-white/10 bg-transparent px-3.5 py-2.5 text-sm outline-none focus:border-primary-400"
            placeholder="e.g. Chef curated, weekly"
          />
          {errors.subtitle && <p className="mt-1 text-xs text-primary-600">{errors.subtitle.message}</p>}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-semibold text-gray-500">Subscribers</label>
            <input
              type="number"
              {...register('subscribers')}
              className="mt-1 w-full rounded-xl border border-borderc dark:border-white/10 bg-transparent px-3.5 py-2.5 text-sm outline-none focus:border-primary-400"
            />
            {errors.subscribers && <p className="mt-1 text-xs text-primary-600">{errors.subscribers.message}</p>}
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500">Price</label>
            <input
              {...register('price')}
              className="mt-1 w-full rounded-xl border border-borderc dark:border-white/10 bg-transparent px-3.5 py-2.5 text-sm outline-none focus:border-primary-400"
              placeholder="e.g. $95/wk"
            />
            {errors.price && <p className="mt-1 text-xs text-primary-600">{errors.price.message}</p>}
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-gray-500">Status</label>
          <select
            {...register('status')}
            className="mt-1 w-full rounded-xl border border-borderc dark:border-white/10 bg-transparent px-3.5 py-2.5 text-sm outline-none focus:border-primary-400"
          >
            <option value="Draft">Draft</option>
            <option value="Active">Active</option>
            <option value="Paused">Paused</option>
          </select>
        </div>

        <div className="flex items-center justify-end gap-2 pt-2">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" disabled={isSubmitting}>
            {isSubmitting ? 'Saving...' : editingPlan ? 'Save Changes' : 'Create Meal Plan'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
