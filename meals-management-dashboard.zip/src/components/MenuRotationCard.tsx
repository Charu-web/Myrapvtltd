import { useState } from 'react'
import { Card } from '@/components/ui/Card'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/ErrorState'
import { MenuRotation } from '@/types'
import { cn } from '@/utils/cn'

export function MenuRotationCard({
  data,
  isLoading,
  isError,
  onRetry,
}: {
  data: MenuRotation | undefined
  isLoading: boolean
  isError: boolean
  onRetry: () => void
}) {
  const [selectedDay, setSelectedDay] = useState<string | null>(null)

  if (isError) {
    return (
      <Card className="p-5">
        <ErrorState onRetry={onRetry} message="Couldn't load the menu rotation." />
      </Card>
    )
  }

  if (isLoading || !data) {
    return (
      <Card className="p-5 space-y-3">
        <Skeleton className="h-4 w-40" />
        <div className="flex gap-2">
          {Array.from({ length: 7 }).map((_, i) => (
            <Skeleton key={i} className="h-14 w-10 rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-16 w-full rounded-xl" />
      </Card>
    )
  }

  const activeDayId = selectedDay ?? data.days.find((d) => d.isSelected)?.id ?? data.days[0].id
  const activePrep = data.prep.find((p) => p.dayId === activeDayId)

  return (
    <Card className="p-5 bg-gradient-to-br from-sky-50 to-white dark:from-white/[0.04] dark:to-white/[0.02]">
      <div className="flex items-start justify-between">
        <h3 className="text-[15px] font-bold text-ink dark:text-white">Menu Rotation (Next 7 Days)</h3>
      </div>
      <p className="mt-1 text-xs font-semibold text-primary-600">Current: {data.currentMenu}</p>

      <div className="mt-4 flex gap-2 overflow-x-auto scrollbar-thin pb-1">
        {data.days.map((day) => {
          const isActive = day.id === activeDayId
          return (
            <button
              key={day.id}
              onClick={() => setSelectedDay(day.id)}
              className={cn(
                'flex flex-col items-center justify-center rounded-xl h-14 w-11 shrink-0 transition-all duration-200',
                isActive
                  ? 'bg-primary-600 text-white shadow-card scale-105'
                  : 'bg-white dark:bg-white/5 text-gray-500 dark:text-gray-300 border border-borderc/60 dark:border-white/10 hover:border-primary-300'
              )}
            >
              <span className="text-[10px] font-semibold uppercase opacity-80">{day.label}</span>
              <span className="text-sm font-bold mt-0.5">{day.date}</span>
            </button>
          )
        })}
      </div>

      {activePrep && (
        <div className="mt-4 rounded-xl bg-white/70 dark:bg-white/5 border border-borderc/50 dark:border-white/10 p-3.5">
          <p className="text-xs font-bold text-ink dark:text-white">{activePrep.title}:</p>
          <p className="mt-1 text-xs text-gray-500 dark:text-gray-400 leading-relaxed">{activePrep.description}</p>
        </div>
      )}
    </Card>
  )
}
