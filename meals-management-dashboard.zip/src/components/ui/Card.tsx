import React from 'react'
import { cn } from '@/utils/cn'

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  as?: 'div' | 'section'
}

export function Card({ className, children, ...props }: CardProps) {
  return (
    <div
      className={cn(
        'bg-white dark:bg-white/[0.04] rounded-2xl shadow-card border border-borderc/60 dark:border-white/10',
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}
