import { FiSearch } from 'react-icons/fi'
import { cn } from '@/utils/cn'

interface SearchInputProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  className?: string
}

export function SearchInput({ value, onChange, placeholder = 'Search...', className }: SearchInputProps) {
  return (
    <div
      className={cn(
        'flex items-center gap-2 rounded-full bg-gray-100 dark:bg-white/5 px-4 py-2.5 w-full max-w-sm transition-colors focus-within:bg-gray-200/70 dark:focus-within:bg-white/10',
        className
      )}
    >
      <FiSearch className="text-gray-400 shrink-0" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="bg-transparent outline-none text-sm w-full placeholder:text-gray-400 text-ink dark:text-gray-100"
      />
    </div>
  )
}
