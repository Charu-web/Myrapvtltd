import { cn } from '@/utils/cn'

const palette = ['#FDA4AF', '#93C5FD', '#86EFAC', '#FCD34D', '#C4B5FD', '#5EEAD4']

function colorFor(seed: string) {
  const idx = seed.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0) % palette.length
  return palette[idx]
}

export function Avatar({
  initials,
  size = 32,
  className,
}: {
  initials: string
  size?: number
  className?: string
}) {
  return (
    <div
      className={cn('flex items-center justify-center rounded-full font-semibold text-ink shrink-0', className)}
      style={{ width: size, height: size, backgroundColor: colorFor(initials), fontSize: size * 0.36 }}
    >
      {initials}
    </div>
  )
}
