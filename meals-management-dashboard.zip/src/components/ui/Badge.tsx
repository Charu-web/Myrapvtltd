import { MealPlanStatus } from '@/types'
import { cn } from '@/utils/cn'

const statusStyles: Record<MealPlanStatus, string> = {
  Active: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400',
  Paused: 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400',
  Draft: 'bg-gray-100 text-gray-500 dark:bg-white/5 dark:text-gray-400',
}

const dotStyles: Record<MealPlanStatus, string> = {
  Active: 'bg-emerald-500',
  Paused: 'bg-amber-500',
  Draft: 'bg-gray-400',
}

export function StatusBadge({ status }: { status: MealPlanStatus }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold',
        statusStyles[status]
      )}
    >
      <span className={cn('h-1.5 w-1.5 rounded-full', dotStyles[status])} />
      {status}
    </span>
  )
}
