import { FiAlertTriangle } from 'react-icons/fi'
import { Button } from './Button'

export function ErrorState({
  message = "Something went wrong. We couldn't load this data.",
  onRetry,
}: {
  message?: string
  onRetry: () => void
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-10 text-center">
      <div className="h-10 w-10 rounded-full bg-primary-50 dark:bg-primary-500/10 flex items-center justify-center text-primary-600">
        <FiAlertTriangle />
      </div>
      <p className="text-sm text-gray-500 dark:text-gray-400 max-w-xs">{message}</p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  )
}
