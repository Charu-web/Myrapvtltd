import { DashboardStats } from '@/types'

export const dashboardStatsData: DashboardStats = {
  totalSubscribers: 482,
  subscribersDelta: '+18 this week',
  activeMealPlans: 12,
  activeMealPlansDelta: '2 in draft',
  monthlyRevenue: 18400,
  monthlyRevenueDelta: '+6.4% vs last mo.',
  fulfillmentRate: 99.2,
}
