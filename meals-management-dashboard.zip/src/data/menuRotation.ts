import { MenuRotation } from '@/types'

export const menuRotationData: MenuRotation = {
  currentMenu: 'Summer Fresh',
  days: [
    { id: 'd1', label: 'Mon', date: 12, isSelected: true, isToday: true },
    { id: 'd2', label: 'Tue', date: 13, isSelected: false, isToday: false },
    { id: 'd3', label: 'Wed', date: 14, isSelected: false, isToday: false },
    { id: 'd4', label: 'Thu', date: 15, isSelected: false, isToday: false },
    { id: 'd5', label: 'Fri', date: 16, isSelected: false, isToday: false },
    { id: 'd6', label: 'Sat', date: 17, isSelected: false, isToday: false },
    { id: 'd7', label: 'Sun', date: 18, isSelected: false, isToday: false },
  ],
  prep: [
    {
      dayId: 'd1',
      title: "Monday's Prep",
      description: 'Grilled Chicken Salads, Quinoa Bowls, Lemon Herb Dressing on the side.',
    },
    {
      dayId: 'd2',
      title: "Tuesday's Prep",
      description: 'Seared Salmon, Roasted Root Vegetables, Dill Yogurt Sauce.',
    },
    {
      dayId: 'd3',
      title: "Wednesday's Prep",
      description: 'Turkey Meatballs, Zucchini Noodles, Marinara & Basil.',
    },
    {
      dayId: 'd4',
      title: "Thursday's Prep",
      description: 'Vegan Buddha Bowls, Tahini Drizzle, Toasted Sesame.',
    },
    {
      dayId: 'd5',
      title: "Friday's Prep",
      description: 'Herb-Crusted Cod, Charred Asparagus, Lemon Butter.',
    },
    {
      dayId: 'd6',
      title: "Saturday's Prep",
      description: 'Weekend Brunch Boxes, Avocado Toast, Fresh Fruit.',
    },
    {
      dayId: 'd7',
      title: "Sunday's Prep",
      description: 'Slow-Roasted Beef, Mashed Potatoes, Seasonal Greens.',
    },
  ],
}
