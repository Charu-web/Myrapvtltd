import { SubscriptionUpdates } from '@/types'

export const subscriptionUpdatesData: SubscriptionUpdates = {
  upcomingRotations: [
    {
      id: 'rot-1',
      kind: 'rotation',
      title: 'Next Week: Mediterranean Theme',
      description: "Starts Aug 19 • Applies to 'Healthy Office'",
    },
    {
      id: 'rot-2',
      kind: 'rotation',
      title: 'Next Week: Autumn Harvest Preview',
      description: "Starts Aug 26 • Applies to 'Family Dinner Bundle'",
    },
    {
      id: 'rot-3',
      kind: 'rotation',
      title: 'Menu Refresh: Keto Reset',
      description: "Starts Sep 2 • Applies to 'Keto Reset Program'",
    },
  ],
  recentCancellations: [
    {
      id: 'can-1',
      kind: 'cancellation',
      title: 'John Doe',
      description: 'Family Dinner Bundle',
      initials: 'JD',
      tag: 'Moving away',
    },
    {
      id: 'can-2',
      kind: 'cancellation',
      title: 'Alice Smith',
      description: 'Vegan Power Bowls',
      initials: 'AS',
      tag: 'Too expensive',
    },
    {
      id: 'can-3',
      kind: 'cancellation',
      title: 'Marcus Lee',
      description: 'Gluten-Free Essentials',
      initials: 'ML',
      tag: 'Portion size',
    },
  ],
  recentNewSubscribers: [
    {
      id: 'new-1',
      kind: 'new-subscriber',
      title: 'Priya Nair',
      description: 'Healthy Office Lunch',
      initials: 'PN',
      tag: 'Referral',
    },
    {
      id: 'new-2',
      kind: 'new-subscriber',
      title: 'Tom Becker',
      description: 'Athlete Fuel Pack',
      initials: 'TB',
      tag: 'Web signup',
    },
    {
      id: 'new-3',
      kind: 'new-subscriber',
      title: 'Sara Kim',
      description: 'Summer Fresh Rotation',
      initials: 'SK',
      tag: 'Web signup',
    },
    {
      id: 'new-4',
      kind: 'new-subscriber',
      title: 'David Osei',
      description: 'Senior Wellness Meals',
      initials: 'DO',
      tag: 'Referral',
    },
  ],
}
