import axios from 'axios'
import { mealPlansData } from '@/data/mealPlans'
import { dashboardStatsData } from '@/data/dashboardStats'
import { menuRotationData } from '@/data/menuRotation'
import { subscriptionUpdatesData } from '@/data/subscriptionUpdates'
import { MealPlan, DashboardStats, MenuRotation, SubscriptionUpdates } from '@/types'

/**
 * Real axios instance, pre-configured for when a live backend is available.
 * Point VITE_API_BASE_URL at your API and swap the mock* functions below
 * for real axios.get/post/put/delete calls against this client.
 */
export const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? '/api',
  timeout: 10_000,
  headers: { 'Content-Type': 'application/json' },
})

// In-memory store so create/update/delete feel real across a session.
let mealPlansStore: MealPlan[] = [...mealPlansData]

const delay = (ms = 500) => new Promise((resolve) => setTimeout(resolve, ms))

const maybeFail = (failRate = 0) => {
  if (Math.random() < failRate) {
    throw new Error('Network request failed. Please try again.')
  }
}

// GET /api/meal-plans
export async function fetchMealPlans(): Promise<MealPlan[]> {
  await delay(600)
  maybeFail(0)
  return [...mealPlansStore]
}

// GET /api/dashboard
export async function fetchDashboardStats(): Promise<DashboardStats> {
  await delay(450)
  return {
    ...dashboardStatsData,
    activeMealPlans: mealPlansStore.filter((p) => p.status === 'Active').length,
    totalSubscribers: mealPlansStore.reduce((sum, p) => sum + p.subscribers, 0),
  }
}

// GET /api/menu-rotation
export async function fetchMenuRotation(): Promise<MenuRotation> {
  await delay(400)
  return menuRotationData
}

// GET /api/subscriptions
export async function fetchSubscriptionUpdates(): Promise<SubscriptionUpdates> {
  await delay(500)
  return subscriptionUpdatesData
}

// POST /api/meal-plans
export async function createMealPlan(input: Omit<MealPlan, 'id' | 'createdAt'>): Promise<MealPlan> {
  await delay(700)
  const newPlan: MealPlan = {
    ...input,
    id: `mp-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString().slice(0, 10),
  }
  mealPlansStore = [newPlan, ...mealPlansStore]
  return newPlan
}

// PUT /api/meal-plans/:id
export async function updateMealPlan(id: string, patch: Partial<MealPlan>): Promise<MealPlan> {
  await delay(600)
  mealPlansStore = mealPlansStore.map((p) => (p.id === id ? { ...p, ...patch } : p))
  const updated = mealPlansStore.find((p) => p.id === id)
  if (!updated) throw new Error('Meal plan not found')
  return updated
}

// DELETE /api/meal-plans/:id
export async function deleteMealPlan(id: string): Promise<{ id: string }> {
  await delay(500)
  mealPlansStore = mealPlansStore.filter((p) => p.id !== id)
  return { id }
}
